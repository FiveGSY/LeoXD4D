let handler = async (m, { conn, usedPrefix, command }) => {
		
			await conn.sendMessage(m.chat, { image: { url: dir[Math.floor(Math.random() * dir.length)] }, caption: `_raiden cute_` }, { quoted: m })
	 }
	 
handler.help = ['raiden']
handler.tags = ['internet']
handler.command = /^(raiden)$/i
handler.limit = true

module.exports = handler

const dir = [
'https://i.pixiv.re/img-original/img/2021/09/04/08/14/11/92491279_p0.png',
'https://px.s.rainchan.win/img-original/img/2021/08/22/03/44/19/92166886_p0.jpg',
'https://i.jitsu.top/img-original/img/2021/09/22/00/10/58/92921790_p0.jpg',
'https://pixiv.yuki.sh/img-original/img/2021/10/19/16/46/01/93548652_p0.png',
'https://i.jitsu.top/img-original/img/2022/07/28/17/51/56/100055330_p0.jpg',
'https://px.s.rainchan.win/img-original/img/2021/10/27/18/37/58/93718696_p0.jpg',
'https://i.pixiv.re/img-original/img/2022/06/26/00/00/06/99301400_p0.jpg',
'https://px.s.rainchan.win/img-original/img/2022/04/20/18/18/27/97757217_p0.jpg',
'https://px3.rainchan.win/img-original/img/2022/08/30/00/19/35/100857830_p0.png',
'https://pixiv.yuki.sh/img-original/img/2021/10/18/00/00/04/93518009_p0.jpg',
'https://px.s.rainchan.win/img-original/img/2022/03/07/12/46/28/96742171_p0.jpg',
'https://i.jitsu.top/img-original/img/2022/02/06/00/41/44/96031125_p0.jpg',
'https://px.s.rainchan.win/img-original/img/2021/09/08/09/49/00/92592369_p0.png',
'https://pixiv.yuki.sh/img-original/img/2022/09/20/00/00/10/101351475_p0.jpg',
'https://pixiv.yuki.sh/img-original/img/2022/02/05/00/05/26/96004213_p0.jpg',
'https://px.s.rainchan.win/img-original/img/2022/11/26/00/10/50/103095356_p0.png',
'https://px2.rainchan.win/img-original/img/2022/12/07/19/36/44/103416776_p0.png',
'https://px2.rainchan.win/img-original/img/2021/09/22/00/10/08/92921764_p0.png',
'https://i.pixiv.re/img-original/img/2022/07/18/00/00/29/99800683_p0.png',
'https://px.s.rainchan.win/img-original/img/2021/10/01/00/46/16/93133125_p0.jpg',
'https://px3.rainchan.win/img-original/img/2022/03/17/04/07/01/96966664_p0.jpg',
'https://px3.rainchan.win/img-original/img/2022/07/01/10/47/23/99421094_p0.png',
'https://i.pixiv.re/img-original/img/2022/09/26/00/00/22/101490384_p0.png',
'https://i.pixiv.re/img-original/img/2022/10/31/14/38/55/101174554_p0.jpg',
'https://i.pixiv.re/img-original/img/2022/10/08/16/00/14/101768158_p0.jpg',
'https://px3.rainchan.win/img-original/img/2022/09/20/00/00/10/101351475_p0.jpg',
]
