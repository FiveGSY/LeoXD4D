let handler = async (m, { conn, text, usedPrefix: _p }) => {
  let name = await conn.getName(m.sender)
  let flaaa2 =[
'https://telegra.ph/file/a773a4eca7e4c4bacdca2.jpg',
]
  let user = global.db.data.users[m.sender]
  let message = `
❏ 『 𝙒𝙚𝙡𝙘𝙤𝙢𝙚 𝙩𝙤 𝙞𝙛𝙪𝙣𝙜 𝙨𝙩𝙤𝙧𝙚 』 ❏

╔═════亗ʟɪsᴛ ᴍʟʙʙ 亗════࿐
║ 
║ ❏ .ᴍʟ5ᴅᴍ [ 2ᴋ ]
║ ❏ .ᴍʟ12ᴅᴍ [ 4ᴋ ]
║ ❏ .ᴍʟ19ᴅᴍ [ 6ᴋ ]
║ ❏ .ᴍʟ28ᴅᴍ [ 7ᴋ ]
║ ❏ .ᴍʟ36ᴅᴍ [ 10ᴋ ]
║ ❏ .ᴍʟ44ᴅᴍ [ 11ᴋ ]
║ ❏ .ᴍʟ86ᴅᴍ [ 20ᴋ ]
║ ❏ .ᴍʟ112ᴅᴍ [ 25ᴋ ]
║ ❏ .ᴍʟ172ᴅᴍ [ 40ᴋ ]
║ ❏ .ᴍʟ185ᴅᴍ [ 43ᴋ ]
║ ❏ .ᴍʟ257ᴅᴍ [ 60ᴋ ]
║ 
║ ❏ .ᴍʟᴡᴅᴘ [ 28ᴋ ]
║ ❏ .ᴍʟsᴛᴀʀʟɪɢʜᴛ [ 300ᴋ ]
╚══════════════᭕

➲ 𝙣𝙤𝙩𝙚: 
 ✘ 𝙥𝙚𝙢𝙗𝙖𝙮𝙖𝙧𝙖𝙣 𝙙𝙞𝙡𝙖𝙠𝙪𝙠𝙖𝙣 𝙤𝙡𝙚𝙝 𝙖𝙙𝙢𝙞𝙣
 ✘ 𝙪𝙣𝙩𝙪𝙠 𝙞𝙙 𝙖𝙩𝙖𝙪 𝙨𝙚𝙧𝙫𝙚𝙧 𝙨𝙖𝙡𝙖𝙝 𝙧𝙚𝙨𝙞𝙠𝙤 𝙨𝙚𝙣𝙙𝙞𝙧𝙞
 ✘ 𝙪𝙣𝙩𝙪𝙠 𝙥𝙖𝙮𝙢𝙚𝙣𝙩 𝙗𝙞𝙨𝙖 𝙖𝙡𝙡 𝙥𝙖𝙮𝙢𝙚𝙣𝙩

©𝐌𝐚𝐡𝐢𝐫𝐮 𝐌𝐝 - 𝐀𝐮𝐭𝐡 𝐛𝐲 𝐢𝐟𝐮𝐧𝐠 ༒`
conn.sendPresenceUpdate("composing", m.chat)
conn.sendMessage(m.chat, {
text: message,
contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
title: "𝙼𝚊𝚑𝚒𝚛𝚞 𝙼𝙳 - 𝙱𝚢 𝚒𝚏𝚞𝚗𝚐ツ",
body: "『 𝐈𝐟𝐮𝐧𝐠 𝐬𝐭𝐢𝐥𝐥 𝐥𝐞𝐚𝐫𝐧𝐢𝐧𝐠 』.",
thumbnailUrl: pickRandom(flaaa2),
sourceUrl: "https://ifungstore.my.id/mylink",
mediaType: 1,
renderLargerThumbnail: true
}}})
}

handler.customPrefix = /^(mlbb|.mlbb)$/i
handler.command = new RegExp
handler.register = true

module.exports = handler

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}
