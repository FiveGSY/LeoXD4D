const fetch = require ('node-fetch')
let handler = async (m, { text,  usedPrefix,  command }) => {
    if (!text) throw `Nino Hello open ai character can?`
let ayaka = await fetch(`https://api-charaai.vercel.app/charaai?chara=Nino&text=${text}`)
let hasil = await ayaka.json()
 let awe = `${hasil}`.trim()
    conn.sendMessage(m.chat, {
text: awe,
contextInfo: {
externalAdReply: {
title: 'C-ai by bahiru',
body: 'Mahiru',
thumbnailUrl: "https://telegra.ph/file/2d12a1410d557115fef6d.jpg",
sourceUrl: "-",
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['nino']
handler.tags = ['cai']
handler.command = /^(cai-nino|ai-nino)$/i
module.exports = handler