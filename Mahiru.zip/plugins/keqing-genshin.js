let handler = async (m, { conn, usedPrefix, command }) => {
		
			await conn.sendMessage(m.chat, { image: { url: dir[Math.floor(Math.random() * dir.length)] }, caption: `_keqing bau_` }, { quoted: m })
	 }
	 
handler.help = ['keqing']
handler.tags = ['internet']
handler.command = /^(keqing)$/i
handler.limit = 3

module.exports = handler

const dir = [
'https://px2.rainchan.win/img-original/img/2021/11/21/21/30/51/94283464_p0.png',
'https://i.jitsu.top/img-original/img/2022/11/17/00/00/09/102850683_p0.png',
'https://i.pixiv.re/img-original/img/2020/11/03/00/00/07/85423062_p0.png',
'https://px3.rainchan.win/img-original/img/2022/11/22/19/24/10/103007375_p0.png',
'https://px2.rainchan.win/img-original/img/2022/05/07/01/03/36/98161069_p1.png',
'https://i.jitsu.top/img-original/img/2022/02/27/16/17/14/96556845_p0.jpg',
'https://px3.rainchan.win/img-original/img/2022/01/10/14/29/45/95432479_p0.jpg',
'https://px.s.rainchan.win/img-original/img/2021/12/29/13/54/03/95105246_p0.jpg',
'https://i.pixiv.re/img-original/img/2022/03/09/00/01/52/96776291_p0.jpg',
'https://i.pixiv.re/img-original/img/2022/11/24/00/00/16/103044337_p1.jpg',
'https://i.jitsu.top/img-original/img/2022/03/25/01/51/14/97152189_p0.png',
'https://i.jitsu.top/img-original/img/2021/07/28/17/55/52/91557748_p1.jpg',
'https://pixiv.yuki.sh/img-original/img/2021/04/24/20/04/09/89362139_p0.png',
'https://pixiv.yuki.sh/img-original/img/2021/04/13/19/07/00/89128635_p0.jpg',
'https://px.s.rainchan.win/img-original/img/2020/12/17/23/30/01/86360532_p0.png',
'https://px.s.rainchan.win/img-original/img/2020/12/21/13/01/33/86434134_p0.png',
'https://px3.rainchan.win/img-original/img/2022/12/14/00/00/03/103584811_p0.jpg',
'https://i.jitsu.top/img-original/img/2021/08/08/14/11/12/91812708_p0.png',
'https://px2.rainchan.win/img-original/img/2022/05/24/12/50/44/98568532_p0.jpg',
'https://i.pixiv.re/img-original/img/2022/02/28/00/00/24/96570128_p0.jpg',
'https://px.s.rainchan.win/img-original/img/2022/03/12/15/28/31/96854887_p0.png',
'https://px2.rainchan.win/img-original/img/2021/05/22/18/48/46/90015173_p0.jpg',
'https://i.pixiv.re/img-original/img/2020/11/03/00/00/07/85423062_p0.png',
'https://pixiv.yuki.sh/img-original/img/2021/11/22/20/00/04/94303069_p0.jpg',
'https://px.s.rainchan.win/img-original/img/2021/10/08/18/00/00/93303181_p0.jpg',
'https://i.pixiv.re/img-original/img/2022/11/13/15/13/57/102755657_p0.png',
'https://px2.rainchan.win/img-original/img/2022/06/02/00/00/44/98765176_p0.png',
'https://px2.rainchan.win/img-original/img/2021/12/05/12/48/53/94578449_p0.png',
'https://i.jitsu.top/img-original/img/2022/06/02/00/26/28/98766032_p0.png',
'https://i.jitsu.top/img-original/img/2022/07/11/00/00/00/99641703_p0.png',
]
