let handler = async (m, { conn }) => {
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });
	conn.sendFile(m.chat, 'https://api.xyroinee.xyz/api/sfw/Loli?apikey=WwKr6HjfAO', 'Kemii.jpg', '*Damn Dasar pedo💀*', m)
}
handler.help = ['loli']
handler.tags = ['anime']

handler.command = /^(loli)$/i
handler.premium = false
handler.tags = ['internet']
handler.register = true
handler.limit = 1
module.exports = handler