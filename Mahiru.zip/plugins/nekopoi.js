let handler = async (m, { conn }) => {
  conn.sendMessage(m.chat, {
    react: {
      text: '⏳',
      key: m.key,
    }
  });
	conn.sendFile(m.chat, 'https://api.betabotz.org/api/nsfw/neko2?apikey=Rizalzllk', 'Ikyy.jpg', 'Nekomimi', m)
}
handler.help = ['nekomimi']
handler.tags = ['nsfw']

handler.command = /^(nekomimi|neko)$/i
handler.premium = true
handler.register = true
handler.limit = 5
module.exports = handler