let handler = m => m

const isToxic = /(anjing|ajg|anjg|kontol|memek|mmk|mmek|memk|bangsat|babi|goblok|goblog|kntl|pepek|ppk|ngentod|ngentd|ngntd|kentod|kntd|bgst|anj|fuck|hitam|ireng|jawir|gay|asw|asu|ktl)/i;

handler.before = async function (m, { isAdmin, isBotAdmin }) {
    if (m.isBaileys && m.fromMe)
        return !0
    if (!m.isGroup) return ! 1
    let chat = global.db.data.chats[m.chat]
    let bot = global.db.data.settings[this.user.jid] || {}
    const isAntiToxic = isToxic.exec(m.text)
    let hapus = m.key.participant
    let bang = m.key.id
    if (chat.antiToxic && isAntiToxic && isBotAdmin) {
    await conn.sendMessage(m.chat, { delete: m.key })
    await m.reply('❏ ᴋᴀᴛᴀ ᴋᴀᴛᴀ ᴛᴏxɪᴄ ᴛᴇʀᴅᴇᴛᴇᴋsɪ!\n❏ ʙᴏᴛ ᴀᴋᴀɴ ᴏᴛᴏᴍᴀᴛɪs ᴍᴇɴɢʜᴀᴘᴜs!')
  }
  return true
}

module.exports = handler