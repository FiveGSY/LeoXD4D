let handler = async (m, { conn, args, command }) => {
	let group = m.chat
        await conn.sendImageAsSticker(m.chat, 'https://telegra.ph/file/9c204e39d7356f7807996.png', m, { packname: "Adios", author: "Mahiru Leave" })
        await conn.delay(1000)
        await conn.groupLeave(group)
        }
handler.help = ['gc', 'group']
handler.tags = ['group']
handler.customPrefix = /^(akupergi)$/i
handler.command = new RegExp

handler.mods = true

module.exports = handler