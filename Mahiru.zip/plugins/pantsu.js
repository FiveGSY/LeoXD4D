let handler = async (m, { conn }) => {
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });
	conn.sendFile(m.chat, `https://api.betabotz.org/api/nsfw/panties?apikey=${global.btc}`, 'Kemii.jpg', '2023 © mahiru Md', m)
}
handler.help = ['pantsu']
handler.tags = ['nsfw']

handler.command = /^(pantsu)$/i
handler.premium = true
handler.register = true
handler.limit = 5
module.exports = handler