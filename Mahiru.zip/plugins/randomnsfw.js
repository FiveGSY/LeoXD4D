import fetch from 'node-fetch';
import { pickRandom } from '../../lib/others.js';

const username = [
  "ahegao", "cum", "cuckold", "ass", "bdsm", "blowjob", "femdom", "foot", "gangbang", 
  "gifs", "glasses", "hentai", "manga", "masturbation", "orgy", "panties", "pussy", 
  "tentacles", "thighs", "glasses", "hentai", "zettai", "nekonime", "neko", "neko2"
];

let handler = async (m, { conn, usedPrefix, command }) => {
  try {
    const pickuser = pickRandom(username);
    const res = await fetch(`https://raw.githubusercontent.com/AditPetani/sagiri-datbes/main/nsfw/${pickuser}.json`);
    const data = await res.json();

    if (!data || data.length === 0) {
      throw new Error("No data found");
    }

    const randomImage = pickRandom(data);

    await m.reply("_In progress, please wait..._");
    await conn.sendFile(m.chat, randomImage, '', `_Random Pic: ${pickuser}_`, m, false, { viewOnce: true });
  } catch (error) {
    console.error(error);
    m.reply("_An error occurred while fetching and sending the image._");
  }
};

handler.help = ['randomnsfw'];
handler.tag = ['nsfw'];
handler.command = /^(randomnsfw)$/i;

handler.premium = true;
handler.limit = false;

module.exports = handler