let handler = async (m, { conn }) => {
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });
	conn.sendFile(m.chat, `https://api.betabotz.org/api/nsfw/gangbang?apikey=${global.btc}`, 'Kemii.jpg', '*Wtf 💀*', m)
}
handler.help = ['gangbang']
handler.tags = ['nsfw']

handler.command = /^(gangbang)$/i
handler.premium = true
handler.register = true
handler.limit = 1
module.exports = handler