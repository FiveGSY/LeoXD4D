const axios = require('axios');

const handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `Masukkan pertanyaan!\n\n*Contoh:* Siapa presiden Indonesia?`;

  await m.reply(wait);

  try {
    const response = await axios.get(`https://api.betabotz.org/api/search/openai-chat?text=${text}&apikey=Iky`);
    const message = response.data.message;

    await conn.sendMessage(m.chat, {
      text: message,
      contextInfo: {
        externalAdReply: {
          title: 'Chat GPT',
          body: '',
          thumbnailUrl: "https://telegra.ph/file/7a385897829927b981dfa.jpg",
          sourceUrl: "https://api.betabotz.org",
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m });
  } catch (err) {
    m.reply(err);
  }
};

handler.command = handler.help = ['openai', 'chatgpt'];
handler.tags = ['internet'];
handler.limit = 3;

module.exports = handler;