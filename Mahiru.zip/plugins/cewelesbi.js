let handler = async (m, { conn }) => {
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });
	conn.sendFile(m.chat, 'https://api.fgmods.xyz/api/nsfw/lesbian?apikey=pEQrrO6Q', 'Kemii.jpg', 'Yuri dia gaskan, Yaoi dia tolak', m)
}
handler.help = ['lesbi']
handler.tags = ['nsfw']

handler.command = /^(lesbi)$/i
handler.premium = true
handler.register = true
handler.limit = 5
module.exports = handler