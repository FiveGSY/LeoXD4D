let handler = async (m, { conn }) => {
  conn.sendMessage(m.chat, {
    react: {
      text: '⏳',
      key: m.key,
    }
  });
	conn.sendFile(m.chat, 'https://api.sb-tencent.cn/API/cosplay/index.php', 'Ikyy.jpg', ' Why must loli?💀', m)
}
handler.help = ['loligirls']
handler.tags = ['anime']

handler.command = /^(loligirls)$/i
handler.premium = false
handler.tags = ['internet']
handler.register = true
handler.limit = 2
module.exports = handler