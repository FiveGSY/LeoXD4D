let handler = async (m, { conn, text, usedPrefix: _p }) => {
  let name = await conn.getName(m.sender)
  let flaaa2 =[
'https://telegra.ph/file/2af56753d8b2081d16b0d.jpg']
  let user = global.db.data.users[m.sender]
  let message = `┌─〔 I P - C E K 〕
├ IP ANDA ADALAH ${ip}
└────`
conn.sendPresenceUpdate("composing", m.chat)
conn.sendMessage(m.chat, {
text: message,
contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
title: "Cek ip by mahiru",
body: "Auth by ifung jomok.",
thumbnailUrl: pickRandom(flaaa2),
sourceUrl: "",
mediaType: 1,
renderLargerThumbnail: true
}}})
}

handler.customPrefix = /^(.cekip|.ipcek)$/i
handler.command = new RegExp

module.exports = handler

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}