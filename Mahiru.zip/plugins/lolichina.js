let handler = async (m, { conn }) => {
  conn.sendMessage(m.chat, {
    react: {
      text: '⏳',
      key: m.key,
    }
  });
	conn.sendFile(m.chat, 'https://api.ghser.com/random/pc.php', 'Kemii.jpg', 'Bro?💀 ', m)
}
handler.help = ['lolicn']
handler.tags = ['animecn']

handler.command = /^(lolicn)$/i
handler.premium = false
handler.tags = ['internet']
handler.register = true
handler.limit = 2
module.exports = handler