let handler = async (m, { conn }) => {
  conn.sendMessage(m.chat, {
    react: {
      text: '⏳',
      key: m.key,
    }
  });
	conn.sendFile(m.chat, 'https://api.betabotz.org/api/nsfw/neko?apikey=${global.btc}', 'Ikyy.jpg', 'nekomimi😋', m)
}
handler.help = ['nekomimi18']
handler.tags = ['nsfw']

handler.premium = true
handler.register = true
handler.limit = 5
module.exports = handler