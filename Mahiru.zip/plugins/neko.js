let fetch = require('node-fetch')
let handler = async(m, { conn }) => {
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });
  let res = await fetch('https://api.waifu.pics/nsfw/neko')
  if (!res.ok) throw await res.text()
  let json = await res.json()
  if (!json.url) throw 'Error!'
  conn.sendFile(m.chat, json.url, '', 'Neko😋', m)
}
handler.help = ['neko18']
handler.tags = ['nsfw']
handler.command = /^neko18$/i
handler.limit = true
handler.premium = true

module.exports = handler