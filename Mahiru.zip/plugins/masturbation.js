let handler = async (m, { conn }) => {
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });
	conn.sendFile(m.chat, `https://api.betabotz.org/api/nsfw/hentai?apikey=${global.btc}`, 'Kemii.jpg', '*Tcih sangean*', m)
}
handler.help = ['masturbasi']
handler.tags = ['nsfw']

handler.command = /^(hentai)$/i
handler.premium = true
handler.register = true
handler.limit = 1
module.exports = handler