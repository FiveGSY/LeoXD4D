const axios = require("axios");
let handler = async (m, { text,  usedPrefix,  command }) => {
    if (!text) throw `Mau Nanya Apa???`
    let jam = ['✨'];
  
  for (let i = 0; i < jam.length; i++) {
    await new Promise(resolve => setTimeout(resolve, 100));
    await conn.sendMessage(m.chat, {
      react: {
        text: jam[i],
        key: m.key
      }
    });
  }
let ayaka = await fetch(`https://aemt.me/openai?text=${text}`)
let hasil = await ayaka.json()
 let awe = `${hasil.result}`.trim()
    conn.sendMessage(m.chat, {
text: awe,
contextInfo: {
externalAdReply: {
title: 'Ifunggemink',
body: 'Mahiru',
thumbnailUrl: "https://telegra.ph/file/c215ac7191f9855524fa2.jpg",
sourceUrl: "-",
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['ai', 'openai']
handler.tags = ['main']
handler.command = /^(ai|openai)$/i

module.exports = handler