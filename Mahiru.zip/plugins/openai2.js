const fetch = require("node-fetch");
let handler = async (m, { conn, text }) => {
let d = new Date(new Date + 3600000)
let locale = 'id'
let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
  if (!text) throw '*Example:* .ai cara menang baywan efef'

	conn.sendMessage(m.chat, {
		react: {
			text: '✨',
			key: m.key,
		}
	})
	let a = await fetch (`https://api.azz.biz.id/api/gpt?q=${text}&key=global`)
	let json = await a.json()
let ai = json.respon
conn.reply(m.chat, ai, m, {
      contextInfo: {
        externalAdReply: {
          title: "Openai2 by ifunggemink 
          body: date,
          thumbnailUrl: 'https://telegra.ph/file/b8e738d158bd9d2817fdc.jpg',
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    });
}

handler.command = /^ai2$/i
handler.help = ['ai2 <text>']
handler.tags = ['tools']
handler.register = true
handler.limit = false

module.exports = handler