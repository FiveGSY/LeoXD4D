let { sticker } = require('../lib/sticker.js')

let handler = async (m, { conn }) => { 
let stiker = await sticker(null, global.API(`https://telegra.ph/file/0051176ac1a8e7b71b26b.mp4`), global.packname, global.author)
    if (stiker) return await conn.sendFile(m.chat, stiker, 'sticker.webp', '', m)
}
handler.customPrefix = /^(apip|rafif|rapip|@62895328204304)$/i
handler.command = new RegExp

module.exports = handler