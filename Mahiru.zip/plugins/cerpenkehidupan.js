var fetch = require('node-fetch')

async function handler(m) {
  var kemii = await fetch(`https://api.betabotz.org/api/story/cerpen?type=kehidupan&apikey=${global.btc}`)
  var res = await kemii.json()
  var hasil = `Title: *${res.result.title}*\nAuthor: *${res.result.author}*\n\n${res.result.cerita}`
  await m.reply(hasil)
}

handler.command = handler.help = ['cerpenkehidupan']
handler.tags = ['Cerpen']

module.exports = handler