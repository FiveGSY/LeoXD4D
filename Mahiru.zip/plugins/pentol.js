let handler = async (m, { conn }) => {
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });
	conn.sendImageAsSticker(m.chat, `https://api.betabotz.org/api/sticker/pentol?apikey=${global.btc}`, m, { packname: "2023 © Mahiru-Md"})
}
handler.help = ['pentol']
handler.tags = ['tools']

handler.command = /^(pentol)$/i
handler.premium = false
handler.register = true
handler.limit = 5
module.exports = handler