let handler = async (m, { conn }) => {
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });
	conn.sendImageAsSticker(m.chat, `https://api.betabotz.org/api/sticker/gojosatoru?apikey=${global.btc}`, m, { packname: "2023 © Mahiru-Md"})
}
handler.help = ['gojo']
handler.tags = ['tools']

handler.command = /^(gojo)$/i
handler.premium = false
handler.register = true
handler.limit = 5
module.exports = handler