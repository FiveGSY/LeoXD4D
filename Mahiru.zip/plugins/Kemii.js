let handler = async (m, { conn, text, usedPrefix: _p }) => {
  let name = await conn.getName(m.sender)
  let flaaa2 =[
'https://telegra.ph/file/2af56753d8b2081d16b0d.jpg']
  let user = global.db.data.users[m.sender]
  let message = `
Hello *@${m.sender.split("@")[0]}* mahiru Md online, ada yg bisa dibantu??`
conn.sendPresenceUpdate("composing", m.chat)
conn.sendMessage(m.chat, {
text: message,
contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
title: "Mahiru bots is online",
body: "Klik untuk melihat web owner.",
thumbnailUrl: pickRandom(flaaa2),
sourceUrl: "https://ifungstore.my.id/mylink",
mediaType: 1,
renderLargerThumbnail: true
}}})
}

handler.customPrefix = /^(pp|p)$/i
handler.command = new RegExp

module.exports = handler

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}