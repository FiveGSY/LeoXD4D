let handler = async (m, { conn }) => {
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });
	conn.sendFile(m.chat, `https://api.betabotz.org/api/nsfw/foot?apikey=${global.btc}`, 'Kemii.jpg', '2023 © mahiru Md', m)
}
handler.help = ['foot']
handler.tags = ['nsfw']

handler.command = /^(foot)$/i
handler.premium = true
handler.register = true
handler.limit = 5
module.exports = handler