const axios = require("axios");
let handler = async (m, { conn, text }) => {
let d = new Date(new Date + 3600000)
let locale = 'id'
let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
  if (!text) throw '*Example:* .ai how to get a girlfriend'

	conn.sendMessage(m.chat, {
		react: {
			text: '✨',
			key: m.key,
		}
	})
// the body data is same like openai have.
const payloads = {
	model: "gpt-4",

	// more higher more smart/uncute conversation
	max_tokens: 4000,

	// example of setting the system role;
	// then you can add user role;
	messages: [
		{
			role: "system",
			content:
				"kamu adalah sebuah kecerdasan buatan yg bernama Mahiru, kamu bisa berbicara dalam berbagai bahasa. kepribadian mu adalah pemalu dan apabila ada yang menanyakan pemilik mu dia adalah ifung jomok aseli jawa, jika ada yg menanyakan pasangan owner mu katakan bahwa dia jomblo. ",
		},
	],
};

// Push the user question to { messages };
const question = text;
payloads["messages"].push({
	role: "user",
	content: question,

	// also you can set object { name } if using gpt-4
	name: "makemeow",
});

// make a question to our api
const { data } = await axios
	.request({
		baseURL: "https://api.itsrose.life",
		url: "/chatGPT/turbo",
		method: "POST",
		params: {
			apikey: `${global.rose}`,
		},
		headers: {
			"Content-Type": "application/json",
		},
		data: payloads,
	})
	.catch((e) => e?.response);

const { status, message, result } = data;

if (!status) {
	// error
	return m.reply(message);
}
let ai = result.messages.content
conn.reply(m.chat, ai, m, {
      contextInfo: {
        externalAdReply: {
          title: "Mahiru Ai - auth by ifung",
          body: date,
          thumbnailUrl: 'https://telegra.ph/file/be29df70c4215b11a597e.jpg',
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    });
}

handler.command = /^ai3$/i
handler.help = ['ai3 <text>']
handler.tags = ['tools']
handler.register = true
handler.limit = true

module.exports = handler