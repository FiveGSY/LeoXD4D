var fetch = require('node-fetch')

async function handler(m) {
  var kemii = await fetch(`https://api.betabotz.org/api/story/cerpen?type=misteri&apikey=${global.btc}`)
  var res = await kemii.json()
  var hasil = `Title: *${res.result.title}*\nAuthor: *${res.result.author}*\n\n${res.result.cerita}`
  await m.reply(hasil)
}

handler.command = handler.help = ['cerpenmisteri']
handler.tags = ['Cerpen']

module.exports = handler