let fetch = require('node-fetch');

const username = ["milf", "ahegao", "armpits", "booty", "trap", "ero", "feets", "bigtiddies"];

const handler = async (m, { conn, args, usedPrefix, command }) => {
  let sentImages = 0;
  const maxImages = 1;

  for (let i = 0; i < maxImages; i++) {
    const pickuser = username[i % username.length];
    await m.reply(`_Mengirim gambar ${i + 1}/${maxImages}, please wait..._`);
    try {
      const response = await fetch(`https://api.lolhuman.xyz/api/random/nsfw/${pickuser}?apikey=${global.lolkey}`);
      if (response.status === 200 && response.headers.get('content-type').startsWith('image')) {
        const buffer = await response.buffer();
        conn.sendFile(m.chat, buffer, "", `Random image ${pickuser}`, m);
        sentImages++;
      } else {
        m.reply("Terjadi Kesalahan");
      }
    } catch (error) {
      m.reply("Terjadi Kesalahan");
    }
  }

  m.reply(`_Berhasil mengirimkan ${sentImages} dari ${maxImages} gambar._`);
};

handler.help = ["nsfwimage"];
handler.command = /^(nsfwimage)$/i;
handler.tags = ["nsfw"];
handler.premium = false;
handler.limit = true;
handler.register = true;

module.exports = handler;