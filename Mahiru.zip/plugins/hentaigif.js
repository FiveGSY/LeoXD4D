const { sticker } = require('../lib/sticker.js')

let handler = async (m, { conn, text, usedPrefix, command }) => {
let stiker = await sticker(null, `https://api.zahwazein.xyz/api/morensfw/hentaigif?apikey=zenzkey_c5e42a8b8c31`, global.packname, global.author)
    if (stiker) return conn.sendFile(m.chat, stiker, 'sticker.webp', '', m)
    throw stiker.toString()
    
} 

handler.customPrefix = /^(hentaigif)$/i;
handler.command = new RegExp()
handler.premium = true
module.exports = handler