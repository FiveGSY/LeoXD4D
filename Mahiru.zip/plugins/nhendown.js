const fetch = require('node-fetch')
let handler = async (m, { conn, text }) => {
if (!text) throw 'Mana kode nya '
    try {
        let res = await fetch(`https://api.lolhuman.xyz/api/nhentaipdf/${text}?apikey=${global.lolkey}`)
        let json = await res.json()
        let result = json.result
        conn.sendMessage(m.chat, { document: { url: result }, fileName: `Hasil dari ${text}.pdf`, mimetype: 'application/pdf' }, { quoted: m })
    } catch (error) {
        console.log(error)
        conn.reply(m.chat, 'Terjadi error', m)
    }
}
handler.command = /^(nhendown)$/i
handler.premium = true
module.exports = handler