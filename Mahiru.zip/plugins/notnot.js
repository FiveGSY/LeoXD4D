let handler = async (m, { conn }) => {
	conn.sendFile(m.chat, 'https://api.zahwazein.xyz/randomasupan/notnot?apikey=zenzkey_9d1c091abd30', 'asupan.mp4', 'Nih kak\n2023 © Mahiru-MD', m)
}
handler.help = ['notnot']
handler.tags = ['asupan']

handler.command = /^(notnot|ntnt)$/i
handler.premium = false
handler.register = true
handler.limit = 5
module.exports = handler