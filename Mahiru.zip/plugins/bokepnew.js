var fetch = require('node-fetch')

let handler = async(m, { conn, usedPrefix, command }) => {
    conn.chatRead(m.chat)
	conn.sendMessage(m.chat, {
		react: {
                text: '⏳',
                key: m.key
            }
        })
  let res = await fetch('https://raw.githubusercontent.com/AditPetani/khusus/main/nsfwvid.json')
  let asup = await res.json()
  let json = asup[Math.floor(Math.random() * asup.length)]
  conn.sendFile(m.chat, json.url, 'bokep.mp4', '😋', m)
}
handler.help = ['bokepnew']
handler.tags = ['premium']
handler.limit = false
handler.register = true
handler.vip = true
handler.command = /^(bokepnew)$/i

module.exports = handler