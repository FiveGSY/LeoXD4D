let handler = async (m, { conn }) => {
  conn.sendMessage(m.chat, {
    react: {
      text: '⏲️',
      key: m.key,
    }
  });
	conn.sendFile(m.chat, `https://api.betabotz.org/api/cecan/japan?apikey=${global.btc}`, 'mahiru.jpg', 'Jepang menggoda', m)
}
handler.help = ['japan']
handler.tags = ['asupan']

handler.command = /^(jepang|japan)$/i
handler.premium = false
handler.register = true
handler.limit = 2
module.exports = handler