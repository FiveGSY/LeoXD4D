let handler = async (m, { conn }) => {
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });
	conn.sendFile(m.chat, `https://api.betabotz.org/api/nsfw/femdom?apikey=${global.btc}`, 'Kemii.jpg', '2023 © mahiru Md', m)
}
handler.help = ['femdom']
handler.tags = ['nsfw']

handler.command = /^(femdom)$/i
handler.premium = true
handler.register = true
handler.limit = 5
module.exports = handler