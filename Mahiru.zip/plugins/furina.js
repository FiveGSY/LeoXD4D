let handler = async (m, { conn, usedPrefix, command }) => {
		
			await conn.sendMessage(m.chat, { image: { url: dir[Math.floor(Math.random() * dir.length)] }, caption: `_Furina alias Aqua_` }, { quoted: m })
	}

handler.help = ['furina']
handler.tags = ['anime']
handler.command = /^(furina)$/i
handler.limit = true

module.exports = handler

const dir = [
'https://telegra.ph/file/5c287897f3cd9fd499ac3.jpg',
'https://telegra.ph/file/6bd13a8de5eae52fc25a0.jpg',
'https://telegra.ph/file/f7b5888d88dfe0584a40d.jpg',
'https://telegra.ph/file/2ece4747e54ccfbf86897.jpg',
'https://telegra.ph/file/ec321fa98b89b44f9eb70.jpg',
'https://telegra.ph/file/d988d740922aebb8c7648.jpg',
'https://telegra.ph/file/ae57b845558e66f4ae5ad.jpg',
'https://telegra.ph/file/323ec6856c42abc7af5c4.jpg',
'https://telegra.ph/file/d9b68088135d3631e6e1f.jpg',
'https://telegra.ph/file/dafa8917c705e674fae41.jpg',
'https://telegra.ph/file/bcc07b928cc5b58d9b9b6.jpg',
'https://telegra.ph/file/beee1e37940d5346da047.jpg',
'https://telegra.ph/file/9903ffd640c1444de7935.jpg',
'https://telegra.ph/file/9688f361a1bc142de1d36.jpg',
'https://telegra.ph/file/9d57c76b8d8180a8007bf.jpg',
'https://telegra.ph/file/b92c8db3f3ee69a451338.jpg',
'https://telegra.ph/file/67798c8b0a9aa9e75b009.jpg',
'https://telegra.ph/file/0c6d978fe0c09b1ccb0be.jpg',
'https://telegra.ph/file/0c6d978fe0c09b1ccb0be.jpg',
'https://telegra.ph/file/033450d3a1597ea810b0f.jpg',
'https://telegra.ph/file/8359790bb010bde624cb2.jpg',
'https://telegra.ph/file/228e78ce5531f513c5bd9.jpg',
'https://telegra.ph/file/92fb7b4abebd56eda5a90.jpg',
'https://telegra.ph/file/f0cf32882a48383d7f773.jpg',
'https://telegra.ph/file/7735e9855a963fdb0357f.jpg',
'https://telegra.ph/file/a2283232ea8b61f0e63de.jpg',
'https://telegra.ph/file/456f8728eb0fd6756aab0.jpg',
'https://telegra.ph/file/1d86435d3f8a1fc7c2bfe.jpg',
'https://telegra.ph/file/acb9429a0a2426ce2c393.jpg',
'https://telegra.ph/file/de8b07655ae50d593a365.jpg',
'https://telegra.ph/file/ba8d1352259b0c0606b3e.jpg',
'https://telegra.ph/file/fe66c9a8940811abf7f88.jpg',
'https://telegra.ph/file/6856eff47d6873cfc0976.jpg',
'https://telegra.ph/file/fdc276daee34a91b53322.jpg',
'https://telegra.ph/file/33ede68b4d6a547bf6519.jpg',
'https://telegra.ph/file/4864efaea78d430f6369b.jpg',
'https://telegra.ph/file/f6b2271057aa4664c89e3.jpg',
'https://telegra.ph/file/080dd79287417d80dab9b.jpg',
'https://telegra.ph/file/65bf4c27ea0984241f801.jpg',
'https://telegra.ph/file/706ea484c0b14de961c5a.jpg',
'https://telegra.ph/file/a7b1289ea937c8202ba5f.jpg',
'https://telegra.ph/file/0e4c17ff04dad3a5d3281.jpg',
'https://telegra.ph/file/f2bd8a3cbe58f116ea1f9.jpg',
'https://telegra.ph/file/90529a791ab3dc41b9f9e.jpg',
]
