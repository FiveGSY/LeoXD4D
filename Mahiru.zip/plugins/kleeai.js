const fetch = require ('node-fetch')
let handler = async (m, { text,  usedPrefix,  command }) => {
    if (!text) throw `Klee Hello open ai character can?`
let ayaka = await fetch(`https://api-charaai.vercel.app/charaai?chara=Klee&text=${text}`)
let hasil = await ayaka.json()
 let awe = `${hasil}`.trim()
    conn.sendMessage(m.chat, {
text: awe,
contextInfo: {
externalAdReply: {
title: 'C-ai by bahiru',
body: 'Mahiru',
thumbnailUrl: "https://telegra.ph/file/3d70d816e0e3be756d8b9.jpg",
sourceUrl: "-",
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['klee']
handler.tags = ['cai']
handler.command = /^(cai-klee|ai-klee)$/i
module.exports = handler